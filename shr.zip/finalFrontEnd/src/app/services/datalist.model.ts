export class Datalist
{    username:{type:string}
    firstname:{type:string}
    lastname:{type:string}
    accno:{type:string}
    balance:{type:string}
    add1:{type:string}
    add2:{type:string}
    add3:{type:string}
    city:{type:string}
    state:{type:string}
    Pin:{type:string}
}
