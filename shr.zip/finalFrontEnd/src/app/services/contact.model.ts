export class Contact {
   firstname: { type: string }
   lastname: { type: string }
   email: { type: string }
   subject: { type: string }
   message: { type: string }

}

