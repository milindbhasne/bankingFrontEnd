export class Usertranc {
accountNumber:string;
toAccountNumber:string;
amount:string;
type:string;
transctionType:string;
}


// {
// 	"accountNumber": "AC411101101699989",
// 	"companyName": "phone",
// 	"phoneNumber": "123456",
// 	"type": "company",
// 	"amount": "100"
// }
// "accountNumber":"AC158494367585625",
// "toAccountNumber":"AC150061051423856",
// "amount":500,
// "type":"user"