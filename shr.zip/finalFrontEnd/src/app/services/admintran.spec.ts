import { Admintran } from './admintran';

describe('Admintran', () => {
  it('should create an instance', () => {
    expect(new Admintran()).toBeTruthy();
  });
});
