export class Payment {
  accountNumber:string;
  companyName:string;
  phoneNumber:number;
  type:string;
  balance:number;
  billNumber:number;
  dthNumber:number;
}


