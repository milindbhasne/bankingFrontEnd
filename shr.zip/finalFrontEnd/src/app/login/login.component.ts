import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import {AuthService} from '../services/auth.service';
import { Router } from '@angular/router';
import { DataService } from "../services/data.service";
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  data = [];
  loginForm: FormGroup;


  constructor(private toastr:ToastrService, private dataservice:DataService, private formBuilder: FormBuilder, private routes: Router, private _authService: AuthService) { }

  ngOnInit() {
    console.log(this.data);
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  doLogin(){
    this._authService.login(this.loginForm.value)
      .subscribe(
        res=> {
          this.data = res.data;
           localStorage.setItem('data',JSON.stringify(res.data));
          localStorage.setItem('token',res.token);
          this.dataservice.sendMessage(res.data);
          if(res.data.role=="user")
          {
            console.log("user");
            this.routes.navigate(['/dash/transactions']);
          }
          if(res.data.role=="admin")
          {
            console.log("admin");
            this.routes.navigate(['/admindash']);
          }
        },
        err=> {
        this.toastr.warning('Invaild', 'Credentials');
        console.log("error",err);}
      )
  }
}

