export const environment = {
  production: true,
  PORT: 3000,
  SERVER: '192.168.1.7'
};
