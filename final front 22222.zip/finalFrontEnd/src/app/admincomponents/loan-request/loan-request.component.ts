import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loan-request',
  templateUrl: './loan-request.component.html',
  styleUrls: ['./loan-request.component.css']
})
export class LoanRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
