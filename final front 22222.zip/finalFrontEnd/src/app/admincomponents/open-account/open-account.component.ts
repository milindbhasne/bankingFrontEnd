import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-open-account',
  templateUrl: './open-account.component.html',
  styleUrls: ['./open-account.component.css']
})
export class OpenAccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
