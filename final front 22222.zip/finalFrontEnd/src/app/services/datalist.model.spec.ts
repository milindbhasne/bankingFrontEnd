import { Datalist } from './datalist.model';

describe('Datalist', () => {
  it('should create an instance', () => {
    expect(new Datalist()).toBeTruthy();
  });
});
