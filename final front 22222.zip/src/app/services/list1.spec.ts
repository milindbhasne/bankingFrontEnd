import { List1 } from './list1';

describe('List1', () => {
  it('should create an instance', () => {
    expect(new List1()).toBeTruthy();
  });
});
