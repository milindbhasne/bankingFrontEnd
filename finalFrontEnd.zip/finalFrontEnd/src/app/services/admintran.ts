export class Admintran {
  accountNumber:string;
  amount:string;
}
