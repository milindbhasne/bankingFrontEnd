export class Register {

  firstName:  String;
  lastName:  String;
  account:string;
  address1:  String;
  address2:  String;
  address3:  string;
  city:string;
  state:string;
  pin:string;
  phone:number;
  username:  number;
  email:string;
  password:  string;
  confirmPassword:String;
}



