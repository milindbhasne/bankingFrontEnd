import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-locked-accounts',
  templateUrl: './locked-accounts.component.html',
  styleUrls: ['./locked-accounts.component.css']
})
export class LockedAccountsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
