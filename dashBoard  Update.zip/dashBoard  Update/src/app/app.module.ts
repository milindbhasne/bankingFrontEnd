import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router'

import { AppComponent } from './app.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { EditProfileComponent } from './dashboardComponents/edit-profile/edit-profile.component';
import { AccountsComponent } from './dashboardComponents/accounts/accounts.component';
import { OrdersComponent } from './dashboardComponents/orders/orders.component';
import { PaymentOptionsComponent } from './dashboardComponents/payment-options/payment-options.component';

@NgModule({
  declarations: [
    AppComponent,
    DashBoardComponent,
    EditProfileComponent,
    AccountsComponent,
    OrdersComponent,
    PaymentOptionsComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot([{
    path:'editprofile',
  component:EditProfileComponent},
  {
    path:'accounts',
  component:AccountsComponent},
  {
    path:'orders',
  component:OrdersComponent},
  {
    path:'payments',
  component:PaymentOptionsComponent}
])],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
