import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewservices',
  templateUrl: './viewservices.component.html',
  styleUrls: ['./viewservices.component.css']
})
export class ViewservicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
