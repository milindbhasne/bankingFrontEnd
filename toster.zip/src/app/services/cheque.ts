export class Cheque {

  chequeNo:  String;
  amount:  Number;
  account:String;
  accountNumber:  String;
  date:Date;
  username:String;
}

