import { List } from './list.model';

describe('List', () => {
  it('should create an instance', () => {
    expect(new List()).toBeTruthy();
  });
});
