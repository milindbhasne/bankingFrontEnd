import { Usertranc } from './usertranc';

describe('Usertranc', () => {
  it('should create an instance', () => {
    expect(new Usertranc()).toBeTruthy();
  });
});
